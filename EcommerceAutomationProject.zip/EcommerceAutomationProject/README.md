# E-commerce Automation (GitHub-ready)

## Overview
Maven + Selenium + TestNG + POM sample project automating basic flows of an e-commerce demo site:
- Login
- Search & Add to Cart
- Checkout

This project targets the demo site: https://demo.opencart.com/ (you can change URLs in BaseTest)

## How to run
1. Install Java 11+ and Maven.
2. From project root run:
   ```
   mvn clean test
   ```
3. WebDriver binaries are managed automatically by WebDriverManager.

## Project structure highlights
- `src/main/java/org/ajit/localautomation/pages` - Page Object classes
- `src/test/java/org/ajit/localautomation/tests` - Test classes
- `testng.xml` - TestNG suite
- `pom.xml` - Maven dependencies & build config

## Notes
- This is a sample demo project for learning and interviews. Update locators and flows for your target application.
