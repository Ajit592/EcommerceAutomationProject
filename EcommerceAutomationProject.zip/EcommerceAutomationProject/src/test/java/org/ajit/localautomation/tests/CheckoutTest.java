package org.ajit.localautomation.tests;

import org.ajit.localautomation.pages.CheckoutPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckoutTest extends BaseTest {

    @Test
    public void testCheckoutFlow() {
        CheckoutPage cp = new CheckoutPage(driver);
        // Placeholder assertion; replace with real checkout assertions for your app
        Assert.assertTrue(cp.isCheckoutPossible(), "Checkout is possible (placeholder)") ;
    }
}
