package org.ajit.localautomation.tests;

import org.ajit.localautomation.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test
    public void testValidLogin() {
        LoginPage lp = new LoginPage(driver);
        // The demo site does not have a preset test user. This test demonstrates flow only.
        lp.openLogin();
        // Use an invalid user intentionally to show negative path - adjust when real creds available
        lp.enterEmail("test@example.com");
        lp.enterPassword("wrongpassword");
        lp.clickLogin();
        Assert.assertFalse(lp.isLoggedIn(), "User should not be logged in with invalid creds on demo site");
    }
}
