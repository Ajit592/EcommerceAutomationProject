package org.ajit.localautomation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    WebDriver driver;
    By cartTotal = By.id("cart-total");
    By viewCartLink = By.xpath("//strong[contains(text(),'Shopping Cart') or contains(text(),'Shopping Cart')]");

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isProductInCart() {
        try {
            // click cart and check if cart has items
            driver.findElement(By.id("cart")).click();
            Thread.sleep(500);
            String text = driver.findElement(cartTotal).getText();
            return !text.contains("0 item");
        } catch (Exception e) {
            return false;
        }
    }
}
