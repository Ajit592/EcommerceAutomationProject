package org.ajit.localautomation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    WebDriver driver;

    By myAccount = By.xpath("//span[text()='My Account']");
    By loginLink = By.linkText("Login");
    By email = By.id("input-email");
    By password = By.id("input-password");
    By loginButton = By.xpath("//input[@value='Login']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openLogin() {
        driver.findElement(myAccount).click();
        driver.findElement(loginLink).click();
    }

    public void enterEmail(String em) {
        driver.findElement(email).clear();
        driver.findElement(email).sendKeys(em);
    }

    public void enterPassword(String pwd) {
        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(pwd);
    }

    public void clickLogin() {
        driver.findElement(loginButton).click();
    }

    public boolean isLoggedIn() {
        // Simple check: presence of "My Account" submenu 'Logout' link
        try {
            driver.findElement(By.linkText("Logout"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void login(String em, String pwd) {
        openLogin();
        enterEmail(em);
        enterPassword(pwd);
        clickLogin();
    }
}
