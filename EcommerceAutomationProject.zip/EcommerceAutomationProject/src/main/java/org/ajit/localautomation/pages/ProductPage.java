package org.ajit.localautomation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    WebDriver driver;
    By firstProduct = By.cssSelector("div.product-layout div.product-thumb h4 a");
    By addToCartBtn = By.id("button-cart");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openFirstProduct() {
        driver.findElement(firstProduct).click();
    }

    public void addToCart() {
        // On demo site, button may be present on product details
        try {
            driver.findElement(addToCartBtn).click();
        } catch (Exception e) {
            // ignore if not present
        }
    }
}
