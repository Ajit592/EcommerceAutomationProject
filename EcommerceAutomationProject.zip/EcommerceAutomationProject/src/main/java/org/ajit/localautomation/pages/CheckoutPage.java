package org.ajit.localautomation.pages;

import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    // Demo project: detailed checkout flow depends on app. Keep placeholder methods.
    public boolean isCheckoutPossible() {
        return true;
    }
}
